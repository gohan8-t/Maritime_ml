package com.predict.api;

import org.jpmml.evaluator.*;
import org.jpmml.model.PMMLUtil;
import org.dmg.pmml.PMML;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

public class PMMLLoader {
    private static Evaluator evaluator;

    static {
        try {
            PMML pmml;
            try (InputStream is = new FileInputStream("src/main/resources/model.pmml")) {
                pmml = PMMLUtil.unmarshal(is);
            }
            evaluator = new LoadingModelEvaluatorBuilder().load(pmml).build();
            evaluator.verify();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Evaluator getEvaluator() {
        return evaluator;
    }
}