package com.predict.api;

import org.jpmml.evaluator.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PredictService {
    public String predict(Map<String, Object> input) {
        Evaluator evaluator = PMMLLoader.getEvaluator();

        Map<FieldName, FieldValue> arguments = new LinkedHashMap<>();
        for (InputField inputField : evaluator.getInputFields()) {
            Object raw = input.get(inputField.getName().getValue());
            FieldValue value = inputField.prepare(raw);
            arguments.put(inputField.getName(), value);
        }

        Map<FieldName, ?> results = evaluator.evaluate(arguments);
        Object result = results.values().iterator().next();
        return result.toString();
    }
}